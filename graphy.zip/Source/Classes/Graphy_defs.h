/*
 *  Graphy_defs.h
 *  Graphy
 *
 *  Created by Craig McFarlane on 29/11/10.
 *  Copyright 2010 Delaney & Morgan Computing. All rights reserved.
 *
 */

#ifndef Graphy_defs__h
#define Graphy_defs__h

typedef double TCoordinate;
typedef float TWidth;

#endif
