//
//  GraphyXAxis.h
//  Powerage
//
//  Created by Craig McFarlane on 30/11/10.
//  Copyright 2010 Secure Meters. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GraphyAxis.h"


@interface GraphyYAxis : GraphyAxis {

}

@end
